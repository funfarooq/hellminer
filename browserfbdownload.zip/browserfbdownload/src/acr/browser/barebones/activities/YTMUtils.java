package acr.browser.barebones.activities;

import yt.sdk.access.InitializationException;
import yt.sdk.access.YTSDK;
import android.app.Activity;
import android.util.Log;

public class YTMUtils {
	private static YTSDK ytsdk = null;

	public static void initilizeYTSDK(Activity activity) {
		try {
			if (ytsdk == null) {
				ytsdk = YTSDK.getInstance(activity);
				ytsdk.showCustomDialog(activity, true, false);
			}
			ytsdk.setDownloadFolderPath("download");
		} catch (InitializationException e) {
			Log.d("YTSDK", "exception " + e.toString());
		} catch (Exception e) {
			Log.d("YTSDK", "exception " + e.toString());
		}
	}

	public static YTSDK getYTSDK() {
		return ytsdk;
	}
}
