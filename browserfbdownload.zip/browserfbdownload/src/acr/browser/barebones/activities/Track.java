package acr.browser.barebones.activities;

public class Track {

	private int id;
	private String name = "";
	private String singer = "";
	private String album = "";
	private String link = "";
	private String size;
	private String duration;
	private String number = "";
	private String sIconUrl = "";
	private String mIconUrl = "";
	private String lIconUrl = "";
	private int redirect = 0;
	private String source = "";
	private String likes;
	private String time = "";
	private String sId;
	private int downloading = 1;
	private int completed = 0;

	public int getCompleted() {
		return completed;
	}

	public void setCompleted(int completed) {
		this.completed = completed;
	}

	/**
	 * @return the sId
	 */
	public String getsId() {
		return sId;
	}

	/**
	 * @param sId
	 *            the sId to set
	 */
	public void setsId(String sId) {
		this.sId = sId;
	}

	/**
	 * @return the downloading
	 */
	public int getDownloading() {
		return downloading;
	}

	/**
	 * @param downloading
	 *            the downloading to set
	 */
	public void setDownloading(int downloading) {
		this.downloading = downloading;
	}

	/**
	 * @return the likes
	 */
	public String getLikes() {
		return likes;
	}

	/**
	 * @param likes
	 *            the likes to set
	 */
	public void setLikes(String likes) {
		this.likes = likes;
	}

	/**
	 * @return the kbps
	 */
	public String getKbps() {
		return kbps;
	}

	/**
	 * @param kbps
	 *            the kbps to set
	 */
	public void setKbps(String kbps) {
		this.kbps = kbps;
	}

	private String kbps;

	public Track() {

	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the sIconUrl
	 */
	public String getsIconUrl() {
		return sIconUrl;
	}

	/**
	 * @param sIconUrl
	 *            the sIconUrl to set
	 */
	public void setsIconUrl(String sIconUrl) {
		this.sIconUrl = sIconUrl;
	}

	/**
	 * @return the mIconUrl
	 */
	public String getmIconUrl() {
		return mIconUrl;
	}

	/**
	 * @param mIconUrl
	 *            the mIconUrl to set
	 */
	public void setmIconUrl(String mIconUrl) {
		this.mIconUrl = mIconUrl;
	}

	/**
	 * @return the lIconUrl
	 */
	public String getlIconUrl() {
		return lIconUrl;
	}

	/**
	 * @param lIconUrl
	 *            the lIconUrl to set
	 */
	public void setlIconUrl(String lIconUrl) {
		this.lIconUrl = lIconUrl;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the singer
	 */
	public String getSinger() {
		return singer;
	}

	/**
	 * @param singer
	 *            the singer to set
	 */
	public void setSinger(String singer) {
		this.singer = singer;
	}

	/**
	 * @return the album
	 */
	public String getAlbum() {
		return album;
	}

	/**
	 * @param album
	 *            the album to set
	 */
	public void setAlbum(String album) {
		this.album = album;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size
	 *            the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}

	/**
	 * @param duration
	 *            the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number
	 *            the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link
	 *            the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	public int getRedirect() {
		return redirect;
	}

	public void setRedirect(int redirect) {
		this.redirect = redirect;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time
	 *            the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Mp3Track [id=");
		builder.append(id);
		builder.append(", sIconUrl=");
		builder.append(sIconUrl);
		builder.append(", mIconUrl=");
		builder.append(mIconUrl);
		builder.append(", lIconUrl=");
		builder.append(lIconUrl);
		builder.append(", name=");
		builder.append(name);
		builder.append(", singer=");
		builder.append(singer);
		builder.append(", album=");
		builder.append(album);
		builder.append(", size=");
		builder.append(size);
		builder.append(", duration=");
		builder.append(duration);
		builder.append(", number=");
		builder.append(number);
		builder.append(", link=");
		builder.append(link);
		builder.append("]");
		return builder.toString();
	}

}
