package acr.browser.barebones.activities;

import java.util.ArrayList;
import java.util.List;

import fb.downloader.com.R;

import android.app.Activity;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.os.AsyncTask;
import android.provider.MediaStore.Images.Thumbnails;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class DownloadListAdapter extends ArrayAdapter<Track> {

	private final Activity context;
	private final List<Track> catObj;

	private int resourceID;

	private List<View> mStactViewArray;

	public DownloadListAdapter(Activity context, List<Track> objects,
			int resourceID) {
		super(context, resourceID, objects);
		this.context = context;
		this.catObj = objects;

		this.resourceID = resourceID;

		if (objects != null) {
			mStactViewArray = new ArrayList<View>(objects.size());
		}
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {

		LayoutInflater inflater = context.getLayoutInflater();
		View rowView = inflater.inflate(resourceID, null, true);
		TextView txtTitle = (TextView) rowView.findViewById(R.id.itemTitle);
		ImageView videoIcon = (ImageView) rowView.findViewById(R.id.icon);

		txtTitle.setText(catObj.get(position).getName());

		try {

			MyImageItem imageItem = new MyImageItem(videoIcon, catObj.get(
					position).getLink());
			new LoadMediaThumbnail().execute(imageItem);

		} catch (Exception e) {
			// TODO: handle exception
		}

		mStactViewArray.add(position, rowView);
		return rowView;
	}

	private class MyImageItem {

		public ImageView mImageView;
		public String mLocalPath;

		public MyImageItem(ImageView imageView, String localPath) {
			mImageView = imageView;
			mLocalPath = localPath;
		}
	}

	private class LoadMediaThumbnail extends
			AsyncTask<MyImageItem, String, Void> {

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(MyImageItem... params) {

			final MyImageItem imageItem = params[0];

			final Bitmap bmThumbnail = ThumbnailUtils.createVideoThumbnail(
					imageItem.mLocalPath, Thumbnails.MINI_KIND);

			context.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					imageItem.mImageView.setImageBitmap(bmThumbnail);

				}
			});

			return null;
		}

	}

}
