package acr.browser.barebones.activities;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import yt.sdk.jar.player.PlayerActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import fb.downloader.com.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;


public class DownloadList extends Activity {

	private File currentDirectory = new File("/");

	private ListView mGridView;

	LinearLayout progressView;
	DownloadListAdapter mListAdapter;
	List<Track> downloadedList = new ArrayList<Track>();
	private ProgressBar progressBar;
	private TextView progressText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_downloaded_video);
	
		progressView = (LinearLayout) findViewById(R.id.loadingPanel);
		mGridView = (ListView) findViewById(R.id.listView);
		progressBar = (ProgressBar) findViewById(R.id.progressBar);
		progressText = (TextView) findViewById(R.id.progressText);

		new GetVideoListFromYouTube().execute();
		
		

	}

	public void onListItemClick(ListView g, View v, int position, long id) {
		// GlobalAppData.numItemClicked++;

		Intent intent = new Intent(this, PlayerActivity.class);
		intent.putExtra("path", downloadedList.get(position).getLink());

		startActivityForResult(intent, 3);

	}

	private class GetVideoListFromYouTube extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressView.setVisibility(View.VISIBLE);
			mGridView.setVisibility(View.GONE);
		}

		@Override
		protected Void doInBackground(Void... params) {
			if (downloadedList == null) {
				downloadedList = new ArrayList<Track>();
			} else {
				downloadedList.clear();
			}

			browseToRoot();

			return null;
		}

		@Override
		protected void onPostExecute(Void params) {
			// Cancel the Loading Dialog
			progressView.setVisibility(View.GONE);
			addVideoList(downloadedList);
		}

	}

	/**
	 * This function browses to the root-directory of the file-system.
	 */
	private void browseToRoot() {
		File f = new File(Environment.getExternalStorageDirectory() + "/"
				+ "fbdownloader" + "/");
		System.out.println(f.getAbsolutePath());
		browseTo(f);
	}

	private void browseTo(final File aDirectory) {
		if (!aDirectory.exists()) {
			aDirectory.mkdirs();// Create Directory if doesnt Exists
		}

		if (aDirectory.isDirectory()) {
			this.currentDirectory = aDirectory;
			fill(aDirectory.listFiles());
			return;
		}

	}

	private void fill(File[] files) {

		if (files == null || files.length == 0) {
			return;
		}

		try {
			Thread.sleep(10);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		int currentPosOfFileName = this.currentDirectory.getAbsolutePath()
				.length() + 1;

		for (File file : files) {
			Track videoItem = new Track();
			int fileLength = file.getAbsolutePath().length();
			videoItem.setName(file.getAbsolutePath().substring(
					currentPosOfFileName, fileLength));

			videoItem.setLink(file.getPath());

			downloadedList.add(videoItem);
		}

	}

	private void addVideoList(List<Track> videoList) {

		if (videoList == null || videoList.isEmpty()) {
			progressView.setVisibility(View.VISIBLE);
			progressBar.setVisibility(View.GONE);
			progressText.setText("no vidwos found");
		} else {
			downloadedList = videoList;
			mListAdapter = new DownloadListAdapter(this, downloadedList,
					R.layout.item_row);
			if (mGridView != null) {
				mGridView.setAdapter(mListAdapter);
			}

			mGridView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView parent, View view,
						int position, long id) {
					onListItemClick((ListView) parent, view, position, id);
				}
			});
			// }
			mGridView.setVisibility(View.VISIBLE);
			progressView.setVisibility(View.GONE);
		}
	}

	

}