package com.androidhive.musicplayer;




import quran.saber.abdulhakeem.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build.VERSION;

public class First extends Activity {
	private  String SENDER_ID = "525122670206";
	private  String PUSHBOTS_APPLICATION_ID = "51e6805d4deeae735d002cd9";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.first);
			mythread t= new mythread();
			
		t.start();
	}
	class mythread extends Thread{
		public void run(){
			try {
				
				sleep(1000);
				Intent i=new Intent(First.this,AndroidBuildingMusicPlayerActivity.class);
				startActivity(i);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		
		
		finish();
		super.onPause();
		
	}

}
