package com.androidhive.musicplayer;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;

import quran.saber.abdulhakeem.R;

public class SongsManager {
	// SDCard Path
	final String MEDIA_PATH = new String("/sdcard/");
    String link= "http://server12.mp3quran.net/hkm/";
	String []extra=new String[]{"001.mp3",
			"002.mp3",
			"003.mp3",
			"004.mp3",
			"005.mp3",
			"006.mp3",
			"007.mp3",
			"008.mp3",
			"009.mp3",
			"010.mp3",
			"011.mp3",
			"012.mp3",
			"013.mp3",
			"014.mp3",
			"015.mp3",
			"016.mp3",
			"017.mp3",
			"018.mp3",
			"019.mp3",
			"020.mp3",
			"021.mp3",
			"022.mp3",
			"023.mp3",
			"024.mp3",
			"025.mp3",
			"026.mp3",
			"027.mp3",
			"028.mp3",
			"029.mp3",
			"030.mp3",
			"031.mp3",
			"032.mp3",
			"033.mp3",
			"034.mp3",
			"035.mp3",
			"036.mp3",
			"037.mp3",
			"038.mp3",
			"039.mp3",
			"040.mp3",
			"041.mp3",
			"042.mp3",
			"043.mp3",
			"044.mp3",
			"045.mp3",
			"046.mp3",
			"047.mp3",
			"048.mp3",
			"049.mp3",
			"050.mp3",
			"051.mp3",
			"052.mp3",
			"053.mp3",
			"054.mp3",
			"055.mp3",
			"056.mp3",
			"057.mp3",
			"058.mp3",
			"059.mp3",
			"060.mp3",
			"061.mp3",
			"062.mp3",
			"063.mp3",
			"064.mp3",
			"065.mp3",
			"066.mp3",
			"067.mp3",
			"068.mp3",
			"069.mp3",
			"070.mp3",
			"071.mp3",
			"072.mp3",
			"073.mp3",
			"074.mp3",
			"075.mp3",
			"076.mp3",
			"077.mp3",
			"078.mp3",
			"079.mp3",
			"080.mp3",
			"081.mp3",
			"082.mp3",
			"083.mp3",
			"084.mp3",
			"085.mp3",
			"086.mp3",
			"087.mp3",
			"088.mp3",
			"089.mp3",
			"090.mp3",
			"091.mp3",
			"092.mp3",
			"093.mp3",
			"094.mp3",
			"095.mp3",
			"096.mp3",
			"097.mp3",
			"098.mp3",
			"099.mp3",
			"100.mp3",
			"101.mp3",
			"102.mp3",
			"103.mp3",
			"104.mp3",
			"105.mp3",
			"106.mp3",
			"107.mp3",
			"108.mp3",
			"109.mp3",
			"110.mp3",
			"111.mp3",
			"112.mp3",
			"113.mp3",
			"114.mp3"};
	String[] names=new String[]{"1	Al-Fatihah ",
			"2	Al-Baqarah ",
			"3	Al-Imran ",
			"4	An-Nisa' ",
			"5	Al-Ma'idah ",
			"6	Al-An'am ",
			"7	Al-A'raf ",
			"8	Al-Anfal ",
			"9	At-Taubah ",
			"10	Yunus ",
			"11	Hood ",
			"12	Yusuf ",
			"13	Ar-Ra'd ",
			"14	Ibrahim ",
			"15	Al-Hijr ",
			"16	An-Nahl ",
			"17	Al-Isra ",
			"18	Al-Kahf ",
			"19	Maryam ",
			"20	Ta�Ha ",
			"21	Al-Anbiya'", 
			"22	Al-Hajj ",
			"23	Al-Mu'minun", 
			"24	An-Nur ",
			"25	Al-Furqan", 
			"26	Ash-Shu'ara'", 
			"27	An-Naml ",
			"28	Al-Qasas ",
			"29	Al-'Ankabut", 
			"30	Ar�Room ",
			"31	Luqman ",
			"32	As�Sajdah", 
			"33	Al�Ahzab ",
			"34	Saba' ",
			"35	Fatir ",
			"36	Ya�Sin ",
			"37	As-Saffat", 
			"38	Sad ",
			"39	Az-Zumar", 
			"40	Ghafir ",
			"41	Fussilat ",
			"42	Ash-Shura ",
			"43	Az-Zukhruf ",
			"44	Ad-Dukhan ",
			"45	Al-Jathiya ",
			"46	Al-Ahqaf ",
			"47	Muhammad ",
			"48	Al-Fath ",
			"49	Al-Hujurat", 
			"50	Qaf ",
			"51	Az-Zariyat", 
			"52	At-Tur ",
			"53	An-Najm ",
			"54	Al-Qamar ",
			"55	Ar-Rahman ",
			"56	Al-Waqi'ah ",
			"57	Al-Hadid ",
			"58	Al-Mujadilah ",
			"59	Al-Hashr ",
			"60	Al-Mumtahinah ",
			"61	As-Saff ",
			"62	Al-Jumu'ah ",
			"63	Al-Munafiqun ",
			"64	At-Taghabun ",
			"65	At-Talaq ",
			"66	At-Tahrim ",
			"67	Al-Mulk ",
			"68	Al-Qalam ",
			"69	Al-Haqqah ",
			"70	Al-Ma'arij ",
			"71	Nooh ",
			"72	Al-Jinn ",
			"73	Al-Muzzammil ",
			"74	Al-Muddaththir ",
			"75	Al-Qiyamah ",
			"76	Al-Insan ",
			"77	Al-Mursalat ",
			"78	An-Naba' ",
			"79	An-Nazi'at ",
			"80	Abasa ",
			"81	At-Takwir ",
			"82	Al-Infitar ",
			"83	Al-Mutaffifin ",
			"84	Al-Inshiqaq ",
			"85	Al-Buruj ",
			"86	At-Tariq ",
			"87	Al-A'la ",
			"88	Al-Ghashiyah ",
			"89	Al-Fajr ",
			"90	Al-Balad ",
			"91	Ash-Shams ",
			"92	Al-Lail ",
			"93	Ad-Duha ",
			"94	Ash-Sharh ",
			"95	At-Tin ",
			"96	Al-'Alaq ",
			"97	Al-Qadr ",
			"98	Al-Baiyinah ",
			"99	Az-Zalzalah ",
			"100	Al-'Adiyat ",
			"101	Al-Qari'ah ",
			"102	At-Takathur ",
			"103	Al-'Asr ",
			"104	Al-Humazah ",
			"105	Al-Fil ",
			"106	Quraish ",
			"107	Al-Ma'un ",
			"108	Al-Kauthar ",
			"109	Al-Kafirun ",
			"110	An-Nasr ",
			"111	Al-Masad ",
			"112	Al-Ikhlas ",
			"113	Al-Falaq ","114 al-NAAS"};
	private ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();
	
	// Constructor
	public SongsManager(){
		
	}
	
	/**
	 * Function to read all mp3 files from sdcard
	 * and store the details in ArrayList
	 * @param names2 
	 * */
	public ArrayList<HashMap<String, String>> getPlayList(String[] tem){
		

 {
	 

			for (int i=0;i<114;i++) {
				HashMap<String, String> song = new HashMap<String, String>();
				song.put("songTitle", tem[i]);
				String temp=link+extra[i];
				song.put("songPath", temp);
				
				// Adding each song to SongList
				songsList.add(song);
			}
		}
		// return songs list array
		return songsList;
	}
	
	/**
	 * Class to filter files which are having .mp3 extension
	 * */
	class FileExtensionFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.endsWith(".mp3") || name.endsWith(".MP3"));
		}
	}

	
}
