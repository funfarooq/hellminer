package com.androidhive.musicplayer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import quran.saber.abdulhakeem.R;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class PlayListActivity extends ListActivity {
	// Songs list
	public ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();
	final Context context = this;
	
	String name;
	
	String foldername;
	ProgressDialog mProgressDialog,pd;
	int flag=0,i,pos;
	int songIndex;
	 CharSequence[] items;
	 String[] names;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.playlist);
		 name=(String) this.getTitle();
		 foldername="/"+name;
	//	Toast.makeText(this, foldername, Toast.LENGTH_LONG).show();

		ArrayList<HashMap<String, String>> songsListData = new ArrayList<HashMap<String, String>>();
        names= this.getResources().getStringArray(R.array.surahnames);
		SongsManager plm = new SongsManager();
		// get all songs from sdcard
		this.songsList = plm.getPlayList(names);
ImageButton bt1=(ImageButton)findViewById(R.id.listPlaylist);
bt1.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View arg0) { 
		mProgressDialog = new ProgressDialog(PlayListActivity.this);
		mProgressDialog.setMessage(songsList.get(pos).get("songTitle")+"downloading..");
		mProgressDialog.setIndeterminate(false);
		mProgressDialog.setMax(100);
		
		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

		// execute this when the downloader must be fired
		DownloadFile downloadFile = new DownloadFile();
		
		downloadFile.execute(songsList.get(pos).get("songPath"));
		pos++;
        flag=1;
        
		
		
	}});
		// looping through playlist
		for (int i = 0; i < songsList.size(); i++) {
			// creating new HashMap
			HashMap<String, String> song = songsList.get(i);

			// adding HashList to ArrayList
			songsListData.add(song);
		}
		items = this.getResources().getStringArray(R.array.downloadall);
		// Adding menuItems to ListView
		ListAdapter adapter = new SimpleAdapter(this, songsListData,
				R.layout.playlist_item, new String[] { "songTitle" }, new int[] {
						R.id.songTitle });

		setListAdapter(adapter);

		// selecting single ListView item
		ListView lv = getListView();
		// listening to single listitem click
		lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            public boolean onItemLongClick(AdapterView<?> arg0, View v,
                    int index, long arg3) {
                // TODO Auto-generated method stub
            	Log.e("","long pressed");
            	AlertDialog.Builder builder = new AlertDialog.Builder(context);
            	builder.setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    	mProgressDialog = new ProgressDialog(PlayListActivity.this);
                    	mProgressDialog.setMessage(songsList.get(pos).get("songTitle")+"/n"+getResources().getString(R.string.downloading));
                    		mProgressDialog.setIndeterminate(false);
                		mProgressDialog.setMax(100);
                		
                		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

                		// execute this when the downloader must be fired
                		DownloadFile downloadFile = new DownloadFile();
                		
                		downloadFile.execute(songsList.get(pos).get("songPath"));
                		pos++;
                        flag=1;
                    }});
            	AlertDialog alertDialog = builder.create();
           	 
				// show it
				alertDialog.show();
            	
                return true;
            }
}); 
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					final int position, long id) {
				 songIndex = position;	pos=position;
				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
					context);
	 
				// set title
				alertDialogBuilder.setTitle(songsList.get(position).get("songTitle"));
	 
				// set dialog message
				alertDialogBuilder
					.setMessage(getResources().getString(R.string.downloadmess))
					.setCancelable(true)
					.setPositiveButton(getResources().getString(R.string.play),new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,int id) {
							int songIndex = position;
							
							// Starting new intent
							Intent in = new Intent(getApplicationContext(),
									AndroidBuildingMusicPlayerActivity.class);
							// Sending songIndex to PlayerActivity
							in.putExtra("songIndex", songIndex);
							setResult(100, in);
							// Closing PlayListView
							finish();
							
							
						}
					  })
					.setNegativeButton(getResources().getString(R.string.download),new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,int id) {
							File dir = new File(Environment.getExternalStorageDirectory() +foldername+"/"+songIndex+".mp3");
		        				 if(dir.exists()){
		        					 Toast.makeText(getApplicationContext(), getResources().getString(R.string.fileexists),Toast.LENGTH_SHORT).show();
		        				 }
		        				 else{
       						mProgressDialog = new ProgressDialog(PlayListActivity.this);
       						mProgressDialog.setMessage("downloading"+songsList.get(songIndex).get("songTitle"));
       						mProgressDialog.setIndeterminate(false);
       						mProgressDialog.setMax(100);
       						mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

       						// execute this when the downloader must be fired
       						DownloadFile downloadFile = new DownloadFile();
       						downloadFile.execute(songsList.get(songIndex).get("songPath"));
						
						}}
					});
	 
					// create alert dialog
					AlertDialog alertDialog = alertDialogBuilder.create();
	 
					// show it
					alertDialog.show();
				
				
			}
		});

	}
private class DownloadFile extends AsyncTask<String, Integer, String> {
		
	    @Override
	    protected String doInBackground(String... sUrl) {
	        try {
	        	
	            URL url = new URL(sUrl[0]);
	            URLConnection connection = url.openConnection();
	            connection.connect();
	            // this will be useful so that you can show a typical 0-100% progress bar
	            int fileLength = connection.getContentLength();
	            String newFolder = foldername;
	            String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
	            File myNewFolder = new File(extStorageDirectory + newFolder);
	            myNewFolder.mkdir();
	            // download the file
	            InputStream input = new BufferedInputStream(url.openStream());
	            OutputStream output;
	            if(flag==1)
	            {
	            	int temp=pos-1;
	          output = new FileOutputStream("/sdcard/"+newFolder+"/"+temp+".mp3");
	            }
	            else
	            	  output = new FileOutputStream("/sdcard/"+newFolder+"/"+pos+".mp3"); 	
	            byte data[] = new byte[1024];
	            long total = 0;
	            int count;
	            while ((count = input.read(data)) != -1) {
	                total += count;
	                // publishing the progress....
	                publishProgress((int) (total * 100 / fileLength));
	                output.write(data, 0, count);
	            }

	            output.flush();
	            output.close();
	            input.close();
	        } catch (Exception e) {
	        }
	        return null;
	    }
	    protected void onPreExecute() {
	        super.onPreExecute();
	        if(flag==1)
	        	pos++;
	        mProgressDialog.show();
	    }

	    @Override
	    protected void onProgressUpdate(Integer... progress) {
	        super.onProgressUpdate(progress);
	        mProgressDialog.setProgress(progress[0]);
	    }
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			mProgressDialog.dismiss();
			if(flag==1){
				i=i+1;
			
				
  				
				mProgressDialog = new ProgressDialog(PlayListActivity.this);
				mProgressDialog.setMessage(songsList.get(pos).get("songTitle")+"/n"+getResources().getString(R.string.downloading));
				mProgressDialog.setIndeterminate(false);
				mProgressDialog.setMax(100);
				
				mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

				// execute this when the downloader must be fired
				DownloadFile downloadFile = new DownloadFile();
				
				downloadFile.execute(songsList.get(pos).get("songPath"));
			  
  				 }
				if(i>=114)
					flag=0;
			
		}
	
	}
public final  boolean onCreateOptionsMenu(Menu mymenu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.menu, mymenu);
	return true;
  
  }
public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
    case R.id.exit:
          this.finish();
          return true;
    case R.id.download:
    	
    	mProgressDialog = new ProgressDialog(PlayListActivity.this);
		mProgressDialog.setMessage(songsList.get(pos).get("songTitle")+"downloading..");
		mProgressDialog.setIndeterminate(false);
		mProgressDialog.setMax(100);
		
		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

		// execute this when the downloader must be fired
		DownloadFile downloadFile = new DownloadFile();
		
		downloadFile.execute(songsList.get(pos).get("songPath"));
		pos++;
        flag=1;
        
        return true;
   
    default:
          return super.onOptionsItemSelected(item);
    }}
}
